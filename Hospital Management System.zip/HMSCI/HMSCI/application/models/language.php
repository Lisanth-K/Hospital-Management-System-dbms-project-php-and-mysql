<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Language extends CI_Model {
	
	function __construct()
    {
        parent::__construct();
    }
	
	function language($email , $password)
	{

	}
	
	
}

